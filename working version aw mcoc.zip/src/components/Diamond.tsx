import React from 'react';

export const Diamond: React.FC = () => {
  return (
    <div className="w-12 h-12 border-2 border-yellow-500 bg-yellow-900/50 rotate-45 transform" />
  );
};