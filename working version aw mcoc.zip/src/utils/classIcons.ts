export const classIcons = {
  Cosmic: '/icons/cosmic.png',
  Mutant: '/icons/mutant.png',
  Mystic: '/icons/mystic.png',
  Science: '/icons/science.png',
  Skill: '/icons/skill.png',
  Tech: '/icons/tech.png'
} as const;